import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// Configure Firebase using FlutterFire CLI before enabling real auth/database.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // TODO: add firebase_options.dart and:
  // await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // FirebaseAuth and Firestore are referenced to document intended services.
  try { FirebaseAuth.instance; FirebaseFirestore.instance; } catch (_) {}
  runApp(const FFTournamentApp());
}

class FFTournamentApp extends StatelessWidget {
  const FFTournamentApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'FF Tournament',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark),
      scaffoldBackgroundColor: const Color(0xFF0B1020),
      useMaterial3: true,
    ),
    home: const HomePage(),
  );
}

class Tournament {
  final String title, mode, entry, prize, start, status;
  final int slots;
  const Tournament(this.title, this.mode, this.entry, this.prize, this.start, this.slots, this.status);
}
const tournaments = [
  Tournament('Daily Solo Clash', 'Solo', 'Free', '৳500', 'আজ • 8:00 PM', 48, 'Registration Open'),
  Tournament('Duo Rush Cup', 'Duo', '৳20', '৳1,000', 'আজ • 9:00 PM', 24, 'Registration Open'),
  Tournament('Squad Survival', 'Squad', '৳50', '৳3,000', 'আগামীকাল • 7:30 PM', 12, 'Coming Soon'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  String mode = 'All';
  void message(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  @override Widget build(BuildContext context) {
    final pages = [_tournaments(), const RegisterPage(), const PaymentPage(), const AdminPage()];
    return Scaffold(
      appBar: AppBar(title: const Row(children: [Icon(Icons.sports_esports, color: Color(0xFFA78BFA)), SizedBox(width: 10), Text('FF Tournament', style: TextStyle(fontWeight: FontWeight.w800))]),
        actions: [IconButton(onPressed: () => message('Firebase Authentication কনফিগার করলে লগইন চালু হবে।'), icon: const Icon(Icons.account_circle_outlined))]),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'টুর্নামেন্ট'),
        NavigationDestination(icon: Icon(Icons.person_add_alt_1), label: 'রেজিস্টার'),
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'পেমেন্ট'),
        NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), label: 'অ্যাডমিন'),
      ]),
    );
  }
  Widget _tournaments() {
    final items = tournaments.where((t) => mode == 'All' || t.mode == mode).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF312E81), Color(0xFF7C3AED)]), borderRadius: BorderRadius.circular(22)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('PLAY • COMPETE • WIN', style: TextStyle(letterSpacing: 1.5, fontSize: 12, fontWeight: FontWeight.bold)),
          SizedBox(height: 8), Text('তোমার পরের ম্যাচ\\nএখান থেকেই শুরু!', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          SizedBox(height: 8), Text('Solo, Duo ও Squad টুর্নামেন্টে যোগ দাও।'),
        ])),
      const SizedBox(height: 18), const Text('টুর্নামেন্ট খুঁজুন', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10), Wrap(spacing: 8, children: ['All', 'Solo', 'Duo', 'Squad'].map((m) => ChoiceChip(label: Text(m == 'All' ? 'সব' : m), selected: mode == m, onSelected: (_) => setState(() => mode = m)).toList()),
      const SizedBox(height: 12),
      ...items.map((t) => Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Chip(label: Text(t.mode)), const Spacer(), Text(t.entry, style: TextStyle(color: t.entry == 'Free' ? Colors.greenAccent : Colors.amberAccent, fontWeight: FontWeight.bold))]),
        Text(t.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
        Text('Prize ${t.prize}  •  ${t.start}  •  ${t.slots} slots', style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 12), Row(children: [Expanded(child: Text(t.status, style: const TextStyle(color: Colors.white70, fontSize: 12))), FilledButton(onPressed: () => message('রেজিস্ট্রেশন চালাতে Firebase ও সার্ভার কনফিগার করতে হবে।'), child: const Text('Join now'))]),
      ])))),
      const Text('ডেমো নোট: ম্যাচ/পুরস্কার উদাহরণ মাত্র, বাস্তব টুর্নামেন্টের ঘোষণা নয়।', style: TextStyle(color: Colors.white60, fontSize: 12)),
    ]);
  }
}

class RegisterPage extends StatefulWidget { const RegisterPage({super.key}); @override State<RegisterPage> createState() => _RegisterPageState(); }
class _RegisterPageState extends State<RegisterPage> {
  final phone = TextEditingController(), password = TextEditingController(), ffName = TextEditingController(), uid = TextEditingController();
  bool obscure = true;
  @override void dispose() { phone.dispose(); password.dispose(); ffName.dispose(); uid.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('অ্যাকাউন্ট তৈরি করুন', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 6),
    const Text('মোবাইল নম্বর যাচাই করতে SMS OTP প্রয়োজন হবে।'), const SizedBox(height: 20),
    TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'মোবাইল নম্বর (+8801...)', border: OutlineInputBorder())),
    const SizedBox(height: 12), TextField(controller: password, obscureText: obscure, decoration: InputDecoration(labelText: 'পাসওয়ার্ড', suffixIcon: IconButton(icon: Icon(obscure ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => obscure = !obscure)), border: const OutlineInputBorder())),
    const SizedBox(height: 12), TextField(controller: ffName, decoration: const InputDecoration(labelText: 'Free Fire নাম', border: OutlineInputBorder())),
    const SizedBox(height: 12), TextField(controller: uid, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Free Fire UID', border: OutlineInputBorder())),
    const SizedBox(height: 16), FilledButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('SMS OTP চালু করতে Firebase Phone Authentication সেটআপ করতে হবে। এটি এখন UI ডেমো।'))), icon: const Icon(Icons.sms_outlined), label: const Text('OTP পাঠান')),
    const SizedBox(height: 8), const Text('এই ফর্ম এখনো সার্ভারে তথ্য সংরক্ষণ করে না।', style: TextStyle(color: Colors.white60, fontSize: 12)),
  ]);
}

class PaymentPage extends StatefulWidget { const PaymentPage({super.key}); @override State<PaymentPage> createState() => _PaymentPageState(); }
class _PaymentPageState extends State<PaymentPage> {
  String provider = 'Nagad';
  final trx = TextEditingController(), sender = TextEditingController(), tournament = TextEditingController();
  @override void dispose() { trx.dispose(); sender.dispose(); tournament.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('পেমেন্ট জমা দিন', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 6),
    const Text('bKash বা Nagad-এ পেমেন্ট করে Transaction ID জমা দিন।'), const SizedBox(height: 16),
    SegmentedButton<String>(segments: const [ButtonSegment(value: 'bKash', label: Text('bKash')), ButtonSegment(value: 'Nagad', label: Text('Nagad'))], selected: {provider}, onSelectionChanged: (v) => setState(() => provider = v.first)),
    const SizedBox(height: 16), const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('পেমেন্ট নম্বর অ্যাডমিন দ্বারা কনফিগার করা হবে। টাকা পাঠানোর আগে যাচাইকৃত নম্বর নিশ্চিত করুন।'))),
    const SizedBox(height: 12), TextField(controller: tournament, decoration: const InputDecoration(labelText: 'টুর্নামেন্টের নাম', border: OutlineInputBorder())),
    const SizedBox(height: 12), TextField(controller: sender, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'যে নম্বর থেকে টাকা পাঠিয়েছেন', border: OutlineInputBorder())),
    const SizedBox(height: 12), TextField(controller: trx, decoration: const InputDecoration(labelText: 'Transaction ID', border: OutlineInputBorder())),
    const SizedBox(height: 16), FilledButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সার্ভার যুক্ত না হওয়ায় পেমেন্ট জমা হয়নি। এটি ডেমো ফর্ম।'))), child: const Text('পেমেন্ট যাচাইয়ের জন্য জমা দিন')),
  ]);
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Admin Panel', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
    const Text('দুই অ্যাডমিনের জন্য আলাদা, সার্ভার-যাচাইকৃত লগইন ও অনুমতি যুক্ত করতে হবে।'), const SizedBox(height: 16),
    const _Feature(Icons.verified_user, 'পেমেন্ট রিভিউ', 'Transaction ID যাচাই, approve/reject এবং audit log'),
    const _Feature(Icons.add_circle_outline, 'টুর্নামেন্ট পরিচালনা', 'মোড, এন্ট্রি ফি, পুরস্কার, সময় ও slot'),
    const _Feature(Icons.meeting_room_outlined, 'Room তথ্য', 'শুধু অনুমোদিত খেলোয়াড়দের কাছে Room ID/Password'),
    const _Feature(Icons.leaderboard_outlined, 'ফলাফল প্রকাশ', 'স্কোর, বিজয়ী এবং prize status'),
    const SizedBox(height: 12), const Text('এই স্ক্রিন UI scaffold মাত্র। Admin role ক্লায়েন্ট অ্যাপ থেকে সেট করা যাবে না.', style: TextStyle(color: Colors.white60, fontSize: 12)),
  ]);
}
class _Feature extends StatelessWidget {
  final IconData icon; final String title, detail;
  const _Feature(this.icon, this.title, this.detail);
  @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: const Color(0xFFA78BFA)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(detail)));
}
